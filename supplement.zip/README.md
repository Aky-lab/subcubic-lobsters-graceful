# Reproduction

Extract all files into one directory and run the commands there. The recorded run used CPython 3.12.10 and Node.js 24.22.1. Python 3.10 or later is required. Leave assertions enabled. No third-party packages, network access or solver are needed.

    python audit.py
    python verify_subcubic_lobster.py
    node verify_lobster_language.js subcubic_lobster_rules.json
    python truncation.py
    python all_short.py
    python linear.py

The original note, certificate and two verifiers are byte-identical to the supplied proof bundle. The 250177-byte JSON has SHA-256 f1e26f8a0944ee8de9fd40fdce9310c2360d3ff7d31236737d1a10dc4403e1d7.

audit.py checks the digest, validates all 6104 rows without filtering, and exhausts 175472 reachable trie subsets. The original Python verifier filters on port numbers before checking its rows. With this exact certificate it checks all 6104. Both original coverage implementations report 278215 reachable records and maximum BFS depth 46. The original Python program also tests the constructor.

truncation.py reports shortest failure witnesses 0C0, 0CL, LLLP0, 00C0LC0, LLCL0CL and None at successive length limits. all_short.py enumerates 27 and 170 cumulative admissible transitions of lengths at most one and two, and reports witnesses 0C0 and 0CL. linear.py matches both constructors on 5461 words including empty and checks a 36002-vertex example.

To use the constructor:

    import json
    from pathlib import Path
    from verify_subcubic_lobster import Constructor
    from linear import label_linear
    parser = Constructor(json.loads(Path("subcubic_lobster_rules.json").read_bytes()))
    labels = label_linear(parser, "0CLPC")
    graph_labels = parser.label_tree({0: [1], 1: [0, 2], 2: [1]})

Word labels use (position, slot) keys. Positions start at zero. Slots 0, 1, 2 and 3 denote the spine vertex, head and its children. Slots -1 and -2 denote caps. Graph labels use the original vertex identifiers.

Compile the companion LaTeX manuscript with two runs of pdflatex manuscript.tex from its directory.

Run python marked_join.py to reproduce the marked-vertex bridge example and check the loss of the second attachment.

The optional structural_audit.py uses NetworkX to enumerate unlabelled trees independently of the word representation. From the supplement directory run:

    python -m pip install networkx==3.4.2
    python structural_audit.py

The final row is "total 13188 2233 1758 475" (all trees, subcubic trees, lobsters among them, and remaining subcubic trees). The script verifies every diameter of each lobster, checks labels against original vertices and edges, and tests rejection of each subcubic nonlobster. NetworkX is unnecessary for the proof checks above.
