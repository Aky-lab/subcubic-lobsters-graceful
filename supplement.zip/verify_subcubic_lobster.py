"""Validate local certificates and construct a graceful order for any subcubic lobster word."""
import json
from pathlib import Path
from itertools import product
from collections import defaultdict

def packet(word,start=0,left=False,right=False):
    spine=[(start+i,0) for i in range(len(word))]
    vertices=spine.copy()
    edges=list(zip(spine,spine[1:]))
    for v,letter in zip(spine,word):
        assert letter in '0LPC'
        if letter=='0':continue
        head=(v[0],1)
        vertices.append(head);edges.append((v,head))
        if letter in 'PC':
            child=(v[0],2)
            vertices.append(child);edges.append((head,child))
        if letter=='C':
            child=(v[0],3)
            vertices.append(child);edges.append((head,child))
    for include,v,t in [(left,spine[0],-1),(right,spine[-1],-2)]:
        if include:
            cap=(v[0],t)
            vertices.append(cap);edges.append((v,cap))
    return vertices,edges

def check(f,vertices,edges):
    n=len(vertices)
    assert len(f)==n and set(f)==set(vertices)
    assert sorted(f.values())==list(range(n))
    assert sorted(abs(f[u]-f[v]) for u,v in edges)==list(range(1,n))

def high_class(vertices,edges):
    adj={v:[] for v in vertices}
    for u,v in edges:adj[u].append(v);adj[v].append(u)
    parity={vertices[0]:0};q=[vertices[0]]
    for u in q:
        for v in adj[u]:
            if v not in parity:parity[v]=1-parity[u];q.append(v)
    return {u for u in q if parity[u]==0}

def verify_rule(row):
    a,w,b,labels=row
    assert w and a in (-1,0,1,2,3) and b in (-2,0,1,2,3)
    vertices,edges=packet(w,left=a==-1,right=b==-2)
    f=dict(zip(vertices,labels,strict=True))
    last=(len(w)-1,0)
    if a==-1:
        check(f,vertices,edges)
        assert b==-2 or f[last] in (b,len(f)-1-b)
    else:
        high=high_class(vertices,edges);low=set(vertices)-high
        for side in (high,low):assert sorted(f[v] for v in side)==list(range(len(side)))
        assert sorted(f[u]+f[v] for u,v in edges)==list(range(len(vertices)-1))
        assert f[vertices[0]]==a
        if b!=-2:assert f[last]==len(high if last in high else low)-1-b

def verify_language(rows):
    """Explore the finite recurrence exactly. Every edge out of a reachable state must accept."""
    from functools import cache
    rules=defaultdict(list)
    maxlen=max(len(w) for _,w,_,_ in rows)
    for a,w,b,_ in rows:
        rules[w].append((16 if a==-1 else 1<<a,32 if b==-2 else 1<<b))

    @cache
    def advance(block,mask):
        total=0
        for source,dest in rules.get(block,()):
            if mask&source:total|=dest
        return total

    start=("",(16,))
    seen={start};layer=[start];depth=0
    while layer:
        later=[]
        for suffix,history in layer:
            for c in "0LPC":
                w=suffix+c
                out=0
                for i,mask in enumerate(history,1):
                    out|=advance(w[-i:],mask)
                assert out & 33, ("rejected transition",suffix,history,c)
                new=(w[-(maxlen-1):],((out&15,)+history)[:maxlen])
                if new not in seen:
                    seen.add(new);later.append(new)
        layer=later;depth+=1
    return len(seen),depth-1


class Constructor:
    def __init__(self,rows):
        self.options=defaultdict(list)
        self.longest=max(len(r[1]) for r in rows)
        for row in rows:
            verify_rule(row)
            self.options[row[0],row[1]].append(row)

    def parse(self,word):
        paths=[{} for _ in range(len(word)+1)];paths[0][-1]=None
        for j in range(1,len(word)+1):
            for length in range(1,min(j,self.longest)+1):
                i=j-length;w=word[i:j]
                for a in paths[i]:
                    if a==-2:continue
                    for row in self.options[a,w]:
                        paths[j].setdefault(row[2],(i,a,row))
        choices=paths[-1]
        b=-2 if -2 in choices else 0
        i=len(word);steps=[]
        while i:
            i,b,row=paths[i][b]
            steps.append(row)
        return steps[::-1]

    def label(self,word):
        if not word:return {(0,-1):0,(0,-2):1} # the two-vertex path
        steps=self.parse(word);f={};i=0
        for a,w,b,labels in steps:
            vertices,edges=packet(w,i,a==-1,b==-2)
            block=dict(zip(vertices,labels,strict=True))
            if a==-1:f=block
            else:
                n=len(f)
                if f[i-1,0]!=a:f={u:n-1-x for u,x in f.items()}
                assert f[i-1,0]==a
                high=high_class(vertices,edges);low=set(vertices)-high
                k=len(low)
                f={u:x+k for u,x in f.items()}
                f.update({u:k-1-block[u] for u in low})
                f.update({u:k+n+block[u] for u in high})
            i+=len(w)
        if steps[-1][2]==0:
            if f[i-1,0]!=0:f={u:len(f)-1-x for u,x in f.items()}
            f[i-1,-2]=len(f)
        check(f,*packet(word,left=True,right=True))
        return f

    def label_tree(self,adj):
        """Return labels on the original vertices of a nonempty subcubic lobster."""
        if not adj:raise ValueError("a tree needs a vertex")
        if any(len(row)>3 or len(set(row))!=len(row) or v in row or
               any(w not in adj or v not in adj[w] for w in row) for v,row in adj.items()):
            raise ValueError("expected simple undirected adjacency of maximum degree three")
        first=next(iter(adj))
        def traverse(start):
            parent={start:start};queue=[start]
            for v in queue:
                for w in adj[v]:
                    if w not in parent:parent[w]=v;queue.append(w)
            return queue[-1],parent
        a,component=traverse(first)
        if len(component)!=len(adj) or sum(map(len,adj.values()))!=2*(len(adj)-1):
            raise ValueError("expected a tree")
        if len(adj)==1:return {a:0}
        b,parent=traverse(a)
        path=[b]
        while path[-1]!=a:path.append(parent[path[-1]])
        if len(path)==2:return {a:0,b:1}
        spine=set(path);word=[];names={}
        for i,v in enumerate(path[1:-1]):
            names[i,0]=v
            branches=[w for w in adj[v] if w not in spine]
            if not branches:word.append('0');continue
            head,=branches;names[i,1]=head
            children=[w for w in adj[head] if w!=v]
            if any(len(adj[w])!=1 for w in children):
                raise ValueError("tree is not a lobster")
            word.append('LPC'[len(children)])
            for j,w in enumerate(children,2):names[i,j]=w
        names[0,-1]=path[0];names[len(word)-1,-2]=path[-1]
        labelled=self.label(''.join(word))
        result={names[v]:x for v,x in labelled.items()}
        check(result,list(adj),[(v,p) for v,p in parent.items() if v!=p])
        return result

if __name__=='__main__':
    import sys
    filename=Path(__file__).with_name('subcubic_lobster_rules.json') if len(sys.argv)==1 else Path(sys.argv[1])
    rows=[r for r in json.loads(filename.read_text()) if max(r[0],r[2])<=3]
    c=Constructor(rows)
    print('Validated local rules:',len(rows),flush=True)
    print("Exact language check:",verify_language(rows),flush=True)
    count=0
    for n in range(1,7):
        for w in product('0LPC',repeat=n):
            c.label(''.join(w));count+=1
    for word in ['LCL0LCL','00C00C0000CL','LLLPLP0000LP0','C0LPL000CP','CCLL0PP00']:
        c.label(word*35)
    print('Constructed and checked',count,'short words and five long examples.')
    word="LCL0PP00C0L"*5
    verts,es=packet(word,left=True,right=True)
    adj={v:[] for v in verts}
    for u,v in es:adj[u].append(v);adj[v].append(u)
    check(c.label_tree(adj),verts,es)
    print("Graph-input reconstruction checked.")
