"""Exhaustive graph-input audit on unlabelled trees of orders 1 through 15."""
import json
from itertools import combinations_with_replacement
from pathlib import Path

import networkx as nx

from verify_subcubic_lobster import Constructor


def main():
    rows = json.loads(Path(__file__).with_name("subcubic_lobster_rules.json").read_bytes())
    constructor = Constructor(rows)
    totals = [0] * 4
    print("order trees subcubic lobsters nonlobsters")
    for n in range(1, 16):
        counts = [0] * 4
        trees = [nx.empty_graph(1)] if n == 1 else nx.nonisomorphic_trees(n)
        for g in trees:
            counts[0] += 1
            if max(d for _, d in g.degree()) > 3:
                continue
            counts[1] += 1
            paths = dict(nx.all_pairs_shortest_path(g))
            # In a tree each simple path is determined by its two endpoints.
            def covers(u, v):
                return all(any(len(paths[z][p]) <= 3 for p in paths[u][v]) for z in g)

            pairs = list(combinations_with_replacement(g, 2))
            witness = any(covers(u, v) for u, v in pairs)
            adj = {v: list(g[v]) for v in g}
            if not witness:
                counts[3] += 1
                try:
                    constructor.label_tree(adj)
                except ValueError:
                    continue
                raise AssertionError(("accepted nonlobster", n, list(g.edges)))
            counts[2] += 1
            longest = max(len(paths[u][v]) for u, v in pairs)
            for u, v in pairs:
                if len(paths[u][v]) == longest and not covers(u, v):
                    raise AssertionError(("nonwitnessing diameter", n, u, v, list(g.edges)))
            labels = constructor.label_tree(adj)
            if set(labels) != set(g) or sorted(labels.values()) != list(range(n)):
                raise AssertionError(("bad vertex labels", n, list(g.edges)))
            if sorted(abs(labels[u]-labels[v]) for u, v in g.edges) != list(range(1, n)):
                raise AssertionError(("bad edge differences", n, list(g.edges)))
        print(n, *counts)
        totals = [a+b for a, b in zip(totals, counts)]
    print("total", *totals)


if __name__ == "__main__":
    main()
