"""Independent verification by class parity and determinization of rule tries."""
import hashlib
import json
from collections import deque
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check_row(row):
    a, w, b, labels = row
    require(type(a) is int and a in range(-1, 4), "bad source")
    require(type(b) is int and b in (-2, 0, 1, 2, 3), "bad destination")
    require(1 <= len(w) <= 6 and set(w) <= set("0LPC"), "bad word")
    # For each vertex record its parent in serialization order, and its
    # distance parity from the first spine vertex (the high class).
    parent = [None] + list(range(len(w) - 1))
    parity = [i % 2 for i in range(len(w))]

    def attach(v):
        parent.append(v)
        parity.append(1 - parity[v])
        return len(parent) - 1

    for i, c in enumerate(w):
        if c != "0":
            head = attach(i)
            for _ in range("LPC".index(c)):
                attach(head)
    if a == -1:
        attach(0)
    if b == -2:
        attach(len(w) - 1)
    n = len(parent)
    require(len(labels) == n and all(type(x) is int for x in labels), "bad labels")
    edges = [(labels[i], labels[parent[i]]) for i in range(1, n)]
    last = len(w) - 1
    if a == -1:
        require(sorted(labels) == list(range(n)), "start permutation")
        require(sorted(abs(x-y) for x, y in edges) == list(range(1, n)), "differences")
        require(b == -2 or b in (labels[last], n-1-labels[last]), "start exit")
    else:
        for side in (0, 1):
            indices = [x for x, p in zip(labels, parity) if p == side]
            require(sorted(indices) == list(range(len(indices))), "class permutation")
        require(sorted(x+y for x, y in edges) == list(range(n-1)), "sums")
        require(labels[0] == a, "entry")
        require(b == -2 or labels[last]+b+1 == parity.count(parity[last]), "exit")


def check_language(rows):
    # Five separate prefix tries. At a rule end one may also enter
    # the destination root. The finished marker has no successors.
    children = [{} for _ in range(5)]
    outputs = [set() for _ in range(5)]
    for a, w, b, _ in rows:
        node = 4 if a == -1 else a
        for c in w:
            if c not in children[node]:
                children[node][c] = len(children)
                children.append({})
                outputs.append(set())
            node = children[node][c]
        outputs[node].add(b)

    initial = frozenset([4])
    queue = deque([initial])
    seen = {initial}
    while queue:
        state = queue.popleft()
        for c in "0LPC":
            targets = {children[v][c] for v in state if c in children[v]}
            ends = set().union(*(outputs[v] for v in targets))
            require(0 in ends or -2 in ends, "nonaccepting transition")
            nxt = frozenset({v for v in targets if children[v]} | (ends - {-2}))
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return len(seen)


if __name__ == "__main__":
    raw = Path(__file__).with_name("subcubic_lobster_rules.json").read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    require(digest == "f1e26f8a0944ee8de9fd40fdce9310c2360d3ff7d31236737d1a10dc4403e1d7", "certificate hash")
    rules = json.loads(raw)
    for idx, rule in enumerate(rules):
        try:
            check_row(rule)
        except ValueError as exc:
            raise ValueError(f"row {idx}: {exc}") from exc
    print(f"{len(rules)} rows checked; {check_language(rules)} reachable trie subsets")
