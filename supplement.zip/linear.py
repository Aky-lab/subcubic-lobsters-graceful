"""Construct a graceful labeling in two linear passes over an accepted parse."""
from itertools import product
import json
from pathlib import Path

from verify_subcubic_lobster import Constructor, packet, high_class, check


def label_linear(parser, word):
    if not word:
        return {(0, -1): 0, (0, -2): 1}
    layers = []
    order = pos = 0
    exit_label = None
    for a, w, b, indices in parser.parse(word):
        vertices, edges = packet(w, pos, a == -1, b == -2)
        ranks = dict(zip(vertices, indices, strict=True))
        sign, offset = 1, 0
        if a != -1:
            high = high_class(vertices, edges)
            k = len(vertices) - len(high)
            if exit_label == a:
                offset = k
            else:
                assert order - 1 - exit_label == a
                sign, offset = -1, order - 1 + k
            ranks = {v: order+k+i if v in high else k-1-i for v, i in ranks.items()}
        layers.append((ranks, sign, offset))
        order += len(vertices)
        pos += len(w)
        exit_label = ranks[pos-1, 0]
    if b == 0:
        reflect = exit_label != 0
        layers.append(({(pos-1, -2): order}, -1 if reflect else 1, order-1 if reflect else 0))

    result = {}
    sign, offset = 1, 0
    for ranks, old_sign, old_offset in reversed(layers):
        result.update({v: sign*x+offset for v, x in ranks.items()})
        offset += sign*old_offset
        sign *= old_sign
    return result


if __name__ == "__main__":
    rows = json.loads(Path(__file__).with_name("subcubic_lobster_rules.json").read_bytes())
    parser = Constructor(rows)
    for size in range(7):
        for letters in product("0LPC", repeat=size):
            word = "".join(letters)
            assert label_linear(parser, word) == parser.label(word)
    word = "LPC00CP" * 2000
    labels = label_linear(parser, word)
    check(labels, *packet(word, left=True, right=True))
    print("Matched original on 5461 words including empty; checked", len(labels), "vertices.")
