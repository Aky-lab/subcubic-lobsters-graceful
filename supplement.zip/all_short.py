"""Enumerate all port transitions on one- and two-letter blocks, including caps."""
from itertools import permutations, product

from truncation import shortest_missing
from verify_subcubic_lobster import packet, high_class


def attainable(word, start, finish):
    vertices, edges = packet(word, left=start, right=finish)
    n = len(vertices)
    # Precompute integer edge endpoints, so no graph operations occur in the search.
    edges_i = [(vertices.index(u), vertices.index(v)) for u, v in edges]
    transitions = set()
    last = len(word)-1
    if start:
        for f in permutations(range(n)):
            if f[0] > n-1-f[0]:  # retain one orientation up to global complement
                continue
            if len({abs(f[u]-f[v]) for u, v in edges_i}) == n-1:
                for b in ([-2] if finish else {f[last], n-1-f[last]}):
                    if b <= 3:
                        transitions.add((-1, word, b, ()))
                if finish:
                    break
    else:
        hi = high_class(vertices, edges)
        sides = [[i for i, v in enumerate(vertices) if (v in hi) == high] for high in (True, False)]
        size_last = len(next(s for s in sides if last in s))
        f = [0]*n
        for p in permutations(range(len(sides[0]))):
            for i, x in zip(sides[0], p):
                f[i] = x
            if f[0] > 3:
                continue
            for q in permutations(range(len(sides[1]))):
                for i, x in zip(sides[1], q):
                    f[i] = x
                b = -2 if finish else size_last-1-f[last]
                if b <= 3 and len({f[u]+f[v] for u, v in edges_i}) == n-1:
                    transitions.add((f[0], word, b, ()))
    return transitions


if __name__ == "__main__":
    rows = set()
    for k in (1, 2):
        for chars in product("0LPC", repeat=k):
            for start, finish in product((False, True), repeat=2):
                rows.update(attainable("".join(chars), start, finish))
        print(k, len(rows), shortest_missing(rows, k))
