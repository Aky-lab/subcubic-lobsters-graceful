"""Check a bridge at the center of a star and the exact loss of its extreme rank."""
from verify_subcubic_lobster import check

# A graceful claw with center 0. Attach the two-vertex block e--d at
# the center, using index 0 at both e and d. The old labels shift by 1.
vertices = ["hub", "x", "y", "z", "e", "d"]
edges = [("hub", v) for v in ("x", "y", "z", "e")] + [("e", "d")]
f = dict(zip(vertices, (1, 2, 3, 4, 5, 0), strict=True))
check(f, vertices, edges)
assert {f["hub"], 5-f["hub"]} == {1, 4}
assert [(u, v) for u, v in edges if abs(f[u]-f[v]) == 4] == [("hub", "e")]
print("Bridge at a degree-three hub checked. Its new ranks are 1 and 4.")
