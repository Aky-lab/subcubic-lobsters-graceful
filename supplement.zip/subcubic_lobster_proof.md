# Every lobster of maximum degree at most three is graceful

## Statement and proof strategy

A lobster is a finite tree with a path within distance two of every vertex. A graceful labeling of a tree of order n is a bijection of its vertices onto 0,...,n-1 whose absolute edge differences exhaust 1,...,n-1. **Every lobster of maximum degree at most three has a graceful labeling.**

This is a constructive computer-assisted proof. Its finite data are in subcubic_lobster_rules.json. The proof uses two finite checks: each listed short construction satisfies explicit local equations, and the listed constructions cover every word of every length. Both checks are executable without the code that searched for the constructions. No bound on the diameter or order of the input tree is assumed.

## 1. Encode the tree

Handle the one- and two-vertex trees directly. Extend a witnessing path at both ends to leaves. This does not increase any vertex's distance to the path. At each internal path vertex there is at most one neighbor off the path. Reading the internal vertices from one end to the other gives a nonempty word over four letters:

| Letter | Off-path branch |
|---|---|
| 0 | None |
| L | One leaf |
| P | One neighbor with one leaf child |
| C | One neighbor with two leaf children |

There are no deeper descendants. The two leaves at the ends of the path are the left and right caps of this word. Conversely each word with these caps describes such a tree. For the graph-input routine a diameter path can be used: if some off-path branch has depth at least three, then from its attachment vertex each direction along the diameter also has length at least three, by maximality of the diameter. These three directions cannot all lie within distance two of any single path.

## 2. Local equations and joining lemma

A block is the tree of a substring with only the caps expressly specified. Its first and last internal spine vertices are its entry and exit. A state s in {0,1,2,3} on an already constructed tree of order I means that its exit has rank s or I-1-s in an ordinary graceful labeling. Global complementation lets us use rank s.

A rule row is [a,w,b,f]. The code -1 at entry means start, so the left cap is present; -2 at exit means finished, so the right cap is present. Neither cap appears otherwise. The list f uses the spine vertices first, then off-path branches by increasing spine index (parent before children), then the included caps in left-right order.

A start rule is an ordinary graceful labeling of this block; when b is a port state the last spine rank must be b or its complement. A non-start rule gives each bipartition class its own indices from zero to class size minus one. Each class uses its indices bijectively, and the sums of indices across its edges must cover 0,...,B-2 once each, where B is the block order. The entry index must equal a. For an unfinished block the exit index must equal the size of its own class minus 1 minus b.

To append a non-start block, complement the already labeled tree if necessary to put a at its exit. Call the new class containing the entry high and let k be the size of the other (low) class. Shift all old labels up by k. A low index i receives k-1-i, and a high index j receives k+I+j. These three disjoint bands together use exactly 0,...,I+B-1. The bridge from the previous exit to the entry has difference I, since the two ranks are k+a and k+I+a. The old tree supplies 1,...,I-1, and the edges inside the new block supply I+1,...,I+B-1 because their lengths are I+1+i+j. The prescribed exit index yields rank b on the low side or I+B-1-b on the high side. Thus every rule is sound in every preceding context that supplies its entry state, regardless of the size or shape of that context.

After all letters are read, either a finished rule already supplied the right cap, or state zero suffices: complement to put zero at the last spine vertex, and give the right cap the new maximum. This supplies exactly the last missing length.

## 3. Exhaust the word language by a finite recurrence

There are 6,104 rules, in lengths 1 through 6. Of these, 486 start with the left cap and have a port state at exit; 6 start and finish with both caps. The other 5,574 unfinished and 38 finished rules use the bipartition-index equations. The Python verifier constructs each rule's graph, checks its labels, and checks each required entry, exit, and sum/difference equation directly.

Here is the independent coverage calculation. For any prefix u let P(u) be the set of unfinished states obtainable after parsing it. Initially the empty prefix has the start state alone. To process a new last letter, consider each nonempty suffix w of the new prefix with length at most 6. For a decomposition uw, include every exit b of a rule (a,w,b) with a in P(u). Take the union over those suffixes. The new prefix is accepted if the union contains the finished marker or state zero. Keep only the four unfinished states for future letters: a completed right cap may never be continued. This is an exact recurrence, by considering the last block of any parse.

For every possible next letter the recurrence needs only the last five letters and the state sets of the last six prefixes (including the current prefix). Store these together as a finite state. Start at the empty prefix and explore every transition on each of the four letters, merging only identical states. Reject the certificate if any transition does not accept the resulting word. If the queue empties without rejection, induction on word length proves that every nonempty word has a legal parse. The empty prefix need not itself be accepted.

Both implementations report **278,215 reachable states** including the initial state. The greatest shortest distance from the initial state is 46. All four outgoing transitions at every reachable state pass the acceptance test. This is closure of a finite graph under all possible next letters; the number 46 is not a bound on which words are proved.

Sections 1 and 3 provide a parse for any input lobster of maximum degree at most three. Section 2 turns the parse into a graceful labeling of precisely that tree. This proves the statement.

## Reproduce or use the construction

Use Python 3.10 or later, with assertions enabled, to run

    python verify_subcubic_lobster.py

This validates every local rule, explores the full recurrence, builds labelings for all 5,460 words of lengths 1 through 6 and five longer words, and exercises graph-input reconstruction. Constructor.label(word) labels a specified word. Constructor.label_tree(adjacency) accepts the usual dictionary of undirected neighbor lists and returns a dictionary on the caller's original vertex identifiers. Instantiate Constructor with the decoded JSON rule array.

An independently implemented exact recurrence using base-five suffix codes instead of Python strings is available with Node.js:

    node verify_lobster_language.js subcubic_lobster_rules.json

The SHA-256 digest of the 250,177-byte JSON file is f1e26f8a0944ee8de9fd40fdce9310c2360d3ff7d31236737d1a10dc4403e1d7. Once the table is fixed, neither verifier uses randomness, a solver, or an external service.

## Scope

The global labeling constructed here is ordinary graceful. Only the local non-start rules have the bipartition constraint. For context, earlier work on alpha-labelings proves results under additional hypotheses on the legs and endings; it addresses a stronger constraint on the global labeling (https://www.ic.unicamp.br/~reltech/2017/17-14.pdf). No claim of priority or independent peer review is made. Trees without a path within distance two of every vertex, and trees of maximum degree greater than three, require other arguments.
