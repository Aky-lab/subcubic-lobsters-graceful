"""Compute shortest rejected words after deleting long rows from the fixed table."""
import json
from collections import defaultdict, deque
from functools import cache
from pathlib import Path


def shortest_missing(rows, limit):
    lookup = defaultdict(list)
    for a, w, b, _ in rows:
        if len(w) <= limit:
            lookup[w].append((16 if a == -1 else 1 << a, 32 if b == -2 else 1 << b))

    @cache
    def destinations(w, ports):
        result = 0
        for a, b in lookup[w]:
            if a & ports:
                result |= b
        return result

    start = ("", (16,))
    previous = {start: None}
    todo = deque([start])
    while todo:
        record = todo.popleft()
        suffix, history = record
        for c in "0LPC":
            w = suffix+c
            out = 0
            for i, ports in enumerate(history, 1):
                out |= destinations(w[-i:], ports)
            if not out & 33:
                letters = [c]
                cursor = record
                while previous[cursor] is not None:
                    cursor, char = previous[cursor]
                    letters.append(char)
                return "".join(reversed(letters))
            nxt = (w[1-limit:] if limit > 1 else "", ((out & 15,)+history)[:limit])
            if nxt not in previous:
                previous[nxt] = (record, c)
                todo.append(nxt)
    return None


if __name__ == "__main__":
    rows = json.loads(Path(__file__).with_name("subcubic_lobster_rules.json").read_bytes())
    for limit in range(1, 7):
        print(limit, sum(len(r[1]) <= limit for r in rows), shortest_missing(rows, limit))
