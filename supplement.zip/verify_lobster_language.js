/* Independent exact finite-state check. No dominance pruning is used. */
const fs=require('fs');
const rules=JSON.parse(fs.readFileSync(process.argv[2]));
const alphabet='0LPC', K=Math.max(...rules.map(r=>r[1].length));
const pow=[1];for(let k=1;k<=K;k++)pow.push(5*pow[k-1]);
const table=Array.from({length:pow[K]},()=>new Uint8Array(32));
for(const [a,w,b] of rules){
 let code=0;
 for(const c of w)code=5*code+1+alphabet.indexOf(c);
 const bit=a===-1?16:1<<a, out=b===-2?32:1<<b;
 for(let mask=1;mask<32;mask++)if(mask&bit)table[code][mask]|=out;
}
const mod=pow[K-1], histmod=2**(5*K);
const start=16*mod, seen=new Set([start]);
let layer=[start], depth=0;
while(layer.length){
 let next=[];
 for(const state of layer){
  const suffix=state%mod,hist=(state-suffix)/mod;
  for(let digit=1;digit<=4;digit++){
   let w=5*suffix+digit,m=hist,out=0;
   for(let k=1;k<=K&&m;k++){out|=table[w%pow[k]][m%32];m=Math.floor(m/32);}
   if(!(out&33))throw Error('unaccepted transition at length '+(depth+1)+', state '+state+', digit '+digit);
   const z=((hist*32+(out&15))%histmod)*mod+(w%mod);
   if(!seen.has(z)){seen.add(z);next.push(z);}
  }
 }
 layer=next;depth++;
 if(seen.size>5000000)throw Error('Exact-state check exceeded size bound');
}
console.log('Universal. Exact reachable states:',seen.size,'maximum BFS depth:',depth-1);
